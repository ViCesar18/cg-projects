Nome: Vinícius Cesar dos Santos
Matrícula: 201800560288

** Informações do programa **

Linguagem Utilizada: Python3
Versão do Python: 3.9
OpenGL utilizado: PyOpenGL
Biblioteca para criação e configuração da janela: PyGame

Tamanho da Janela: 1280x720

Ao executar o programa, a janela com a brandeira do Brasil já aparecerá na tela.

Para executar, rode: python3 brazil-flag.py

Para rodar, é necessário possuir as bibliotecas citadas acima, elas podem ser instaladas facilmente rodando:

pip install -U pygame --user

pip install PyOpenGL PyOpenGL_accelerate